package fuchimi;

public class Hand {

	public java.lang.Boolean beats(Hand hand){
		
		return null;
		
	}
		
	public java.lang.Boolean loseAgainst (Rock rock) {
		
		return null;
		
	}

	public java.lang.Boolean loseAgainst (Paper paper) {
	
		return null;
	
	}

	public java.lang.Boolean loseAgainst (Scissors scissor) {
	
		return null;
	
	}
	
	
	
}
